// Main JavaScript for Campus Navigation System

document.addEventListener('DOMContentLoaded', function() {
    // Toggle sidebar
    const hamburgerIcon = document.getElementById('hamburger-icon');
    const sidebar = document.getElementById('sidebar');
    
    if (hamburgerIcon && sidebar) {
        hamburgerIcon.addEventListener('click', function() {
            sidebar.classList.toggle('active');
        });
    }
    
    // Close sidebar on mobile after navigation
    const navLinks = document.querySelectorAll('.sidebar a');
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            if (window.innerWidth <= 768) {
                sidebar.classList.remove('active');
            }
        });
    });
    
    // Avatar upload
    const avatarInput = document.getElementById('avatar-input');
    const userAvatar = document.getElementById('user-avatar');
    const profileIcon = document.getElementById('profile-icon');
    
    if (avatarInput && userAvatar && profileIcon) {
        avatarInput.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    userAvatar.src = e.target.result;
                    profileIcon.src = e.target.result;
                };
                
                reader.readAsDataURL(this.files[0]);
            }
        });
    }
    
    // Profile form submission
    const profileForm = document.getElementById('profile-form');
    if (profileForm) {
        profileForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const fullName = document.getElementById('full-name').value;
            const email = document.getElementById('email').value;
            const phone = document.getElementById('phone').value;
            const address = document.getElementById('address').value;
            const passwordChange = document.getElementById('password-change').value;
            const passwordConfirm = document.getElementById('password-confirm').value;
            
            // Validate password change if provided
            if (passwordChange) {
                if (passwordChange !== passwordConfirm) {
                    alert('Passwords do not match');
                    return;
                }
                // In a real app, you would update the password in the database
            }
            
            // Update profile information
            document.getElementById('profile-name').textContent = fullName;
            
            // In a real app, you would update the user data in the database
            
            alert('Profile updated successfully!');
        });
    }
    
    // Upload form submission
    const uploadForm = document.getElementById('upload-form');
    if (uploadForm) {
        uploadForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('/api/upload_material', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    // Clear form
                    document.getElementById('file-upload').value = '';
                    document.getElementById('file-description').value = '';
                } else {
                    alert(data.message || 'Error uploading file');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while uploading the file');
            });
        });
    }
    
    // Chatbot functionality
    const sendMessageBtn = document.getElementById('send-message');
    const userMessageInput = document.getElementById('user-message');
    const chatMessages = document.getElementById('chat-messages');
    
    function sendMessage() {
        const message = userMessageInput.value.trim();
        
        if (message) {
            // Add user message to chat
            addMessage(message, 'user');
            
            // Clear input
            userMessageInput.value = '';
            
            // Get bot response
            fetch('/api/chatbot', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ message: message }),
            })
            .then(response => response.json())
            .then(data => {
                addMessage(data.response, 'bot');
            })
            .catch(error => {
                console.error('Error:', error);
                addMessage('Sorry, I\'m having trouble connecting right now.', 'bot');
            });
        }
    }
    
    function addMessage(message, sender) {
        const messageElement = document.createElement('div');
        messageElement.classList.add('message', `${sender}-message`);
        
        const contentElement = document.createElement('div');
        contentElement.classList.add('message-content');
        contentElement.textContent = message;
        
        messageElement.appendChild(contentElement);
        chatMessages.appendChild(messageElement);
        
        // Scroll to bottom
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    if (sendMessageBtn && userMessageInput) {
        sendMessageBtn.addEventListener('click', sendMessage);
        userMessageInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                sendMessage();
            }
        });
    }
    
    // Semester selector in academics page
    const semesterSelect = document.getElementById('semester-select');
    if (semesterSelect) {
        semesterSelect.addEventListener('change', function() {
            // In a real app, this would fetch data for the selected semester
            console.log('Selected semester:', this.value);
        });
    }
});