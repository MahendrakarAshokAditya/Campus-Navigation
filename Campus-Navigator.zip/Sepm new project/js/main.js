// Main JavaScript for Campus Navigation System

// DOM Elements
const loginForm = document.getElementById('login-form');
const loginContainer = document.getElementById('login-container');
const mainContainer = document.getElementById('main-container');
const hamburgerIcon = document.getElementById('hamburger-icon');
const sidebar = document.getElementById('sidebar');
const logoutBtn = document.getElementById('logout-btn');
const navLinks = document.querySelectorAll('.sidebar a[data-page]');
const pages = document.querySelectorAll('.page');
const registerLink = document.getElementById('register-link');
const sendMessageBtn = document.getElementById('send-message');
const userMessageInput = document.getElementById('user-message');
const chatMessages = document.getElementById('chat-messages');
const uploadForm = document.getElementById('upload-form');
const profileForm = document.getElementById('profile-form');
const avatarInput = document.getElementById('avatar-input');
const userAvatar = document.getElementById('user-avatar');
const profileIcon = document.getElementById('profile-icon');
const popularLocations = document.getElementById('popular-locations');
const searchBtn = document.getElementById('search-btn');
const locationSearch = document.getElementById('location-search');

// Sample user data (in a real app, this would come from a database)
const users = [
    { username: 'student', password: 'password', name: 'John Doe', id: 'CS12345', program: 'Computer Science' },
    { username: 'admin', password: 'admin123', name: 'Admin User', id: 'AD00001', program: 'Administration' }
];

// Current user
let currentUser = null;

// Sample materials data
const materials = [
    { id: 1, name: 'Introduction to Computer Science', description: 'Basic concepts and fundamentals', type: 'pdf' },
    { id: 2, name: 'Software Engineering Principles', description: 'Best practices and methodologies', type: 'word' },
    { id: 3, name: 'Database Systems', description: 'Relational database concepts', type: 'pdf' },
    { id: 4, name: 'Web Development', description: 'HTML, CSS, and JavaScript basics', type: 'pdf' },
];

// Sample chatbot responses
const botResponses = {
    'hello': 'Hi there! How can I assist you today?',
    'hi': 'Hello! What can I help you with?',
    'help': 'I can help you with information about courses, campus locations, schedules, and more. Just ask!',
    'courses': 'We offer various courses including Computer Science, Software Engineering, Data Science, and more. Check the Academics section for details.',
    'location': 'You can find specific locations using the Maps section. It has an interactive map of the entire campus.',
    'library': 'The library is located in the central campus area. It's open from 8 AM to 10 PM on weekdays.',
    'cafeteria': 'The cafeteria is open from 7 AM to 8 PM. It offers a variety of food options including vegetarian and vegan meals.',
    'attendance': 'You can check your attendance records in the Attendance section. If you have any discrepancies, please contact your course instructor.',
    'exams': 'Exam schedules are posted in the Academics section. Make sure to check regularly for updates.',
    'default': 'I don't have information about that yet. Please contact the administration office for more details.'
};

// Sample campus locations
const campusLocations = {
    'library': { lat: 37.7749, lng: -122.4194, title: 'University Library' },
    'cafeteria': { lat: 37.7750, lng: -122.4180, title: 'Campus Cafeteria' },
    'admin': { lat: 37.7752, lng: -122.4190, title: 'Administration Building' },
    'sports': { lat: 37.7755, lng: -122.4195, title: 'Sports Complex' },
    'cs': { lat: 37.7748, lng: -122.4185, title: 'Computer Science Department' }
};

// Google Map variable
let map;

// Initialize the map
function initMap() {
    // Check if we're on the maps page
    if (!document.getElementById('map')) return;
    
    // Center coordinates from user's specification
    const center = { lat: 37.7749, lng: -122.4194 }; // Using default coordinates as user didn't provide specific ones
    
    // Create the map
    map = new google.maps.Map(document.getElementById('map'), {
        zoom: 16,
        center: center,
    });
    
    // Add markers for campus locations
    Object.values(campusLocations).forEach(location => {
        new google.maps.Marker({
            position: { lat: location.lat, lng: location.lng },
            map: map,
            title: location.title
        });
    });
}

// Event Listeners
document.addEventListener('DOMContentLoaded', function() {
    // Login form submission
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            
            console.log('Login attempt:', username, password);
            
            // Check credentials
            const user = users.find(u => u.username === username && u.password === password);
            
            if (user) {
                console.log('Login successful for user:', user.name);
                // Set current user
                currentUser = user;
                
                // Update profile information
                if (document.getElementById('profile-name')) {
                    document.getElementById('profile-name').textContent = user.name;
                }
                if (document.getElementById('profile-id')) {
                    document.getElementById('profile-id').textContent = 'ID: ' + user.id;
                }
                if (document.getElementById('profile-program')) {
                    document.getElementById('profile-program').textContent = 'Program: ' + user.program;
                }
                if (document.getElementById('full-name')) {
                    document.getElementById('full-name').value = user.name;
                }
                
                // Show main container and hide login
                loginContainer.style.display = 'none';
                mainContainer.style.display = 'flex';
                
                // Show dashboard by default
                showPage('dashboard');
            } else {
                console.error('Login failed: Invalid credentials');
                alert('Invalid username or password. Try using username: student, password: password');
            }
        });
    } else {
        console.error('Login form not found in the DOM');
    }
    
    // Toggle sidebar
    if (hamburgerIcon) {
        hamburgerIcon.addEventListener('click', function() {
            sidebar.classList.toggle('active');
        });
    }
    
    // Navigation links
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const page = this.getAttribute('data-page');
            showPage(page);
            
            // Close sidebar on mobile after navigation
            if (window.innerWidth <= 768) {
                sidebar.classList.remove('active');
            }
        });
    });
    
    // Logout button
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            currentUser = null;
            mainContainer.style.display = 'none';
            loginContainer.style.display = 'flex';
            document.getElementById('username').value = '';
            document.getElementById('password').value = '';
        });
    }
    
    // Register link
    if (registerLink) {
        registerLink.addEventListener('click', function(e) {
            e.preventDefault();
            alert('Registration functionality will be implemented in the future.');
        });
    }
    
    // Send message in chatbot
    if (sendMessageBtn && userMessageInput && chatMessages) {
        sendMessageBtn.addEventListener('click', sendMessage);
        userMessageInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                sendMessage();
            }
        });
    }
    
    // Upload form submission
    if (uploadForm) {
        uploadForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const fileUpload = document.getElementById('file-upload');
            const fileDescription = document.getElementById('file-description').value;
            
            if (fileUpload.files.length > 0) {
                alert(`File "${fileUpload.files[0].name}" uploaded successfully!`);
                fileUpload.value = '';
                document.getElementById('file-description').value = '';
                
                // In a real app, you would send the file to the server here
            } else {
                alert('Please select a file to upload');
            }
        });
    }
    
    // Profile form submission
    if (profileForm) {
        profileForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const fullName = document.getElementById('full-name').value;
            const email = document.getElementById('email').value;
            const phone = document.getElementById('phone').value;
            const address = document.getElementById('address').value;
            const passwordChange = document.getElementById('password-change').value;
            const passwordConfirm = document.getElementById('password-confirm').value;
            
            // Validate password change if provided
            if (passwordChange) {
                if (passwordChange !== passwordConfirm) {
                    alert('Passwords do not match');
                    return;
                }
                // In a real app, you would update the password in the database
            }
            
            // Update profile information
            document.getElementById('profile-name').textContent = fullName;
            
            // In a real app, you would update the user data in the database
            
            alert('Profile updated successfully!');
        });
    }
    
    // Avatar upload
    if (avatarInput && userAvatar && profileIcon) {
        avatarInput.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    userAvatar.src = e.target.result;
                    profileIcon.src = e.target.result;
                };
                
                reader.readAsDataURL(this.files[0]);
            }
        });
    }
    
    // Popular locations in map
    if (popularLocations) {
        const locationItems = popularLocations.querySelectorAll('li');
        locationItems.forEach(item => {
            item.addEventListener('click', function() {
                const locationKey = this.getAttribute('data-location');
                const location = campusLocations[locationKey];
                
                if (location && map) {
                    map.setCenter({ lat: location.lat, lng: location.lng });
                    map.setZoom(18);
                }
            });
        });
    }
    
    // Search location
    if (searchBtn && locationSearch) {
        searchBtn.addEventListener('click', searchLocation);
        locationSearch.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchLocation();
            }
        });
    }
});

// Function to show a specific page
function showPage(pageId) {
    // Hide all pages
    pages.forEach(page => {
        page.style.display = 'none';
    });
    
    // Show the selected page
    const selectedPage = document.getElementById(`${pageId}-page`);
    if (selectedPage) {
        selectedPage.style.display = 'block';
    }
    
    // Initialize map if showing maps page
    if (pageId === 'maps') {
        // Check if the Google Maps API is loaded
        if (typeof google !== 'undefined' && typeof google.maps !== 'undefined') {
            initMap();
        }
    }
}

// Function to send a message in the chatbot
function sendMessage() {
    const message = userMessageInput.value.trim();
    
    if (message) {
        // Add user message to chat
        addMessage(message, 'user');
        
        // Clear input
        userMessageInput.value = '';
        
        // Get bot response
        setTimeout(() => {
            const response = getBotResponse(message);
            addMessage(response, 'bot');
        }, 500);
    }
}

// Function to add a message to the chat
function addMessage(message, sender) {
    const messageElement = document.createElement('div');
    messageElement.classList.add('message', `${sender}-message`);
    
    const contentElement = document.createElement('div');
    contentElement.classList.add('message-content');
    contentElement.textContent = message;
    
    messageElement.appendChild(contentElement);
    chatMessages.appendChild(messageElement);
    
    // Scroll to bottom
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Function to get a response from the chatbot
function getBotResponse(message) {
    const lowerMessage = message.toLowerCase();
    
    // Check for keywords in the message
    for (const keyword in botResponses) {
        if (lowerMessage.includes(keyword)) {
            return botResponses[keyword];
        }
    }
    
    // Return default response if no keyword matches
    return botResponses.default;
}

// Function to search for a location on the map
function searchLocation() {
    const query = locationSearch.value.trim().toLowerCase();
    
    if (!query) return;
    
    // Check if the query matches any known location
    for (const key in campusLocations) {
        if (key.includes(query) || campusLocations[key].title.toLowerCase().includes(query)) {
            const location = campusLocations[key];
            
            if (location && map) {
                map.setCenter({ lat: location.lat, lng: location.lng });
                map.setZoom(18);
                return;
            }
        }
    }
    
    // If no match found
    alert('Location not found on campus map');
}

// Make initMap function globally available for Google Maps callback
window.initMap = initMap;