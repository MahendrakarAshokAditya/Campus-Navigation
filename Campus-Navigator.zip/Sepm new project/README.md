# Campus Navigation System - Flask Application

This is a Flask-based Campus Navigation System that provides various features for students and administrators to navigate and interact with campus resources.

## Features

- User Authentication (Login/Logout)
- Dashboard with quick access to all features
- Course Materials Management
- Interactive Campus Map
- Attendance Records
- Chatbot Assistant
- Academic Records
- User Profile Management

## Installation

1. Make sure you have Python installed (Python 3.7 or higher recommended)

2. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```

## Running the Application

1. Start the Flask development server:
   ```
   python app.py
   ```

2. Open your web browser and navigate to:
   ```
   http://localhost:8000
   ```

## Default Login Credentials

- **Student Account**:
  - Username: student
  - Password: password

- **Admin Account**:
  - Username: admin
  - Password: admin123

## Project Structure

- `app.py` - Main Flask application file
- `templates/` - HTML templates for each page
- `static/` - Static files (CSS, JavaScript, images)
  - `css/` - Stylesheet files
  - `js/` - JavaScript files
  - `images/` - Image files

## Development

This application is currently using sample data. In a production environment, you would connect to a database to store and retrieve user information, materials, attendance records, etc.