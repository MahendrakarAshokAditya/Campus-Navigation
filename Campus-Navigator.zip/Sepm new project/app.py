from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'campus-navigation-secret-key'
app.config['UPLOAD_FOLDER'] = 'static/uploads'

# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Sample user data (in a real app, this would come from a database)
users = [
    {'username': 'student', 'password': 'password', 'name': 'John Doe', 'id': 'CS12345', 'program': 'Computer Science'},
    {'username': 'admin', 'password': 'admin123', 'name': 'Admin User', 'id': 'AD00001', 'program': 'Administration'}
]

# Sample materials data
materials = [
    {'id': 1, 'name': 'Introduction to Computer Science', 'description': 'Basic concepts and fundamentals', 'type': 'pdf'},
    {'id': 2, 'name': 'Software Engineering Principles', 'description': 'Best practices and methodologies', 'type': 'word'},
    {'id': 3, 'name': 'Database Systems', 'description': 'Relational database concepts', 'type': 'pdf'},
    {'id': 4, 'name': 'Web Development', 'description': 'HTML, CSS, and JavaScript basics', 'type': 'pdf'},
]

# Sample chatbot responses
bot_responses = {
    'hello': 'Hi there! How can I assist you today?',
    'hi': 'Hello! What can I help you with?',
    'help': 'I can help you with information about courses, campus locations, schedules, and more. Just ask!',
    'courses': 'We offer various courses including Computer Science, Software Engineering, Data Science, and more. Check the Academics section for details.',
    'location': 'You can find specific locations using the Maps section. It has an interactive map of the entire campus.',
    'library': 'The library is located in the central campus area. It\'s open from 8 AM to 10 PM on weekdays.',
    'cafeteria': 'The cafeteria is open from 7 AM to 8 PM. It offers a variety of food options including vegetarian and vegan meals.',
    'attendance': 'You can check your attendance records in the Attendance section. If you have any discrepancies, please contact your course instructor.',
    'exams': 'Exam schedules are posted in the Academics section. Make sure to check regularly for updates.',
    'default': 'I don\'t have information about that yet. Please contact the administration office for more details.'
}

# Sample campus locations
campus_locations = {
    'library': {'lat': 37.7749, 'lng': -122.4194, 'title': 'University Library'},
    'cafeteria': {'lat': 37.7750, 'lng': -122.4180, 'title': 'Campus Cafeteria'},
    'admin': {'lat': 37.7752, 'lng': -122.4190, 'title': 'Administration Building'},
    'sports': {'lat': 37.7755, 'lng': -122.4195, 'title': 'Sports Complex'},
    'cs': {'lat': 37.7748, 'lng': -122.4185, 'title': 'Computer Science Department'}
}

# User class for Flask-Login
class User(UserMixin):
    def __init__(self, id, username, name, user_id, program):
        self.id = id
        self.username = username
        self.name = name
        self.user_id = user_id
        self.program = program

@login_manager.user_loader
def load_user(user_id):
    for i, user in enumerate(users):
        if i == int(user_id):
            return User(i, user['username'], user['name'], user['id'], user['program'])
    return None

# Routes
@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        for i, user in enumerate(users):
            if user['username'] == username and user['password'] == password:
                user_obj = User(i, user['username'], user['name'], user['id'], user['program'])
                login_user(user_obj)
                session['user_id'] = i
                return redirect(url_for('dashboard'))
        
        flash('Invalid username or password')
        return redirect(url_for('login'))
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    session.pop('user_id', None)
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html')

@app.route('/materials')
@login_required
def materials_page():
    return render_template('materials.html', materials=materials)

@app.route('/maps')
@login_required
def maps_page():
    return render_template('maps.html', locations=campus_locations)

@app.route('/attendance')
@login_required
def attendance_page():
    return render_template('attendance.html')

@app.route('/chatbot')
@login_required
def chatbot_page():
    return render_template('chatbot.html')

@app.route('/academics')
@login_required
def academics_page():
    return render_template('academics.html')

@app.route('/profile')
@login_required
def profile_page():
    return render_template('profile.html')

@app.route('/api/chatbot', methods=['POST'])
def chatbot_api():
    data = request.json
    message = data.get('message', '').lower()
    
    # Check for keywords in the message
    for keyword in bot_responses:
        if keyword in message:
            return jsonify({'response': bot_responses[keyword]})
    
    # Return default response if no keyword matches
    return jsonify({'response': bot_responses['default']})

@app.route('/api/upload_material', methods=['POST'])
@login_required
def upload_material():
    if 'file' not in request.files:
        return jsonify({'success': False, 'message': 'No file part'})
    
    file = request.files['file']
    description = request.form.get('description', '')
    
    if file.filename == '':
        return jsonify({'success': False, 'message': 'No selected file'})
    
    # In a real app, save the file and update the database
    return jsonify({'success': True, 'message': f'File {file.filename} uploaded successfully!'})

if __name__ == '__main__':
    # Create upload folder if it doesn't exist
    if not os.path.exists(app.config['UPLOAD_FOLDER']):
        os.makedirs(app.config['UPLOAD_FOLDER'])
    
    app.run(debug=True, port=8000)